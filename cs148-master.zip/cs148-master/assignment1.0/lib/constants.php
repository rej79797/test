<?php
// print "<p>SQL: " . $sql . "<pre>"; print_r($data); print "</pre></p>";     
// print "<p>Array:<pre>"; print_r($results); print "</pre></p>";
define("DATABASE_NAME", strtoupper(get_current_user()) . '_UVM_Courses_Testing');

define("ADMIN_EMAIL", get_current_user() . "@uvm.edu");

define("LINE_BREAK", "\n");

?>